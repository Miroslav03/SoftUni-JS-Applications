const homeSection = document.getElementById('homePage');


export function showHomeSection(context){
    context.showSection(homeSection)
}   